<script lang="ts" setup>
import { ref, reactive, computed, provide } from 'vue';
import type { _p_TYP, _pp_TYP } from '../../shared/types';

const {_p,_pp} = defineProps<{
    _p: _p_TYP,
    _pp: _pp_TYP,
}>();

const JsonForms = _pp.data.curr.custom.lib[`JsonForms`];
const vanillaRenderers = _pp.data.curr.custom.lib[`vanillaRenderers`];
const defaultStyles = _pp.data.curr.custom.lib[`defaultStyles`];
const mergeStyles = _pp.data.curr.custom.lib[`mergeStyles`];

// Use mergeStyles with default styles (no custom modifications)
const myStyles = mergeStyles(defaultStyles, {});

// Provide the styles
provide('styles', myStyles);

const renderers = Object.freeze([
  ...vanillaRenderers,
]);

const data = reactive({
  number: 5,
});

const schema = {
  properties: {
    number: {
      type: 'number',
    },
  },
};

const uischema = {
  type: 'VerticalLayout',
  elements: [
    {
      type: 'Control',
      scope: '#/properties/number',
    },
  ],
};

const onChange = (event: any) => {
  Object.assign(data, event.data);
  console.log(event.data);
};
</script>

<template>
  <json-forms
    :data="data"
    :schema="schema"
    :uischema="uischema"
    :renderers="renderers"
    @change="onChange"
  />
</template>