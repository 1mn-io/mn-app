import type { _p_TYP, _pp_TYP } from "../shared/types";
import { helper } from "../shared/util/helper/index";
const index = async (_p:_p_TYP) => {
const _helper = await helper();
    
    return {
        set: async (_pp:_pp_TYP) => {
            const _$r = {
                r: ``,
                //style: ``,
            };
            console.log(_pp);
            
             


            //set..
            return _$r;
        }
    };
};

export {index, index as editor};